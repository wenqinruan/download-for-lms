<?php

namespace Custom\Common;

use Symfony\Component\HttpKernel\Exception\HttpException;

class ApiException extends HttpException
{
    public function __construct($statusCode, $message = null, \Exception $previous = null, $code = 0)
    {
        parent::__construct($statusCode, $message, $previous, array(), $code);
    }
}
