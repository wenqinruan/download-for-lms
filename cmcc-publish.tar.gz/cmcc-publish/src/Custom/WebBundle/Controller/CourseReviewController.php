<?php
namespace Custom\WebBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Topxia\Common\ArrayToolkit;
use Topxia\Common\Paginator;
use Topxia\WebBundle\Form\ReviewType;
use Topxia\WebBundle\Controller\CourseBaseController;

class CourseReviewController extends CourseBaseController
{

    public function showAction(Request $request, $courseId)
    {
        list($course, $member) = $this->buildCourseLayoutData($request, $courseId);

        if (!$member) {
            return $this->render('CustomWebBundle:CourseReview:error-modal.html.twig', array('message' => '不是课程成员,不允许评价!', 'course' => $course));
        }

        if ($course['status'] != 'published') {
            return $this->render('CustomWebBundle:CourseReview:error-modal.html.twig', array('message' => '课程还未发布,不允许评价!', 'course' => $course));
        }

        $user = $this->getCurrentUser();

        $userReview = $user->isLogin() ? $this->getReviewService()->getUserCourseReview($user['id'], $course['id']) : null;

        return $this->render('CustomWebBundle:CourseReview:show.html.twig', array(
            'course' => $course,
            'member' => $member,
            'userReview' => $userReview,
            'reviewSaveUrl' => $this->generateUrl('course_review_create', array('id' => $course['id'])),
        ));
    }

    public function listAction(Request $request, $id)
    {
        list($course, $member) = $this->buildCourseLayoutData($request, $id);

        list($reviews, $total) = $this->getReviewService()->findCourseReviews(
            $id,
            $request->query->get('page', 1),
            10
        );

        $paginator = new Paginator(
            $this->get('request'),
            $total,
            10
        );

        $user = $this->getCurrentUser();
        $userReview = $user->isLogin() ? $this->getReviewService()->getUserCourseReview($user['id'], $course['id']) : null;

        return $this->render('CustomWebBundle:Course:reviews.html.twig', array(
            'course' => $course,
            'member' => $member,
            'reviewSaveUrl' => $this->generateUrl('course_review_create', array('id' => $course['id'])),
            'userReview' => $userReview,
            'reviews' => $reviews,
            'paginator' => $paginator
        ));
    }


    public function createAction(Request $request, $id)
    {
        $user = $this->getCurrentUser();
        $course = $this->getCourseService()->getCourse($id);
        if ($course['status'] != 'published') {
            return $this->createJsonResponse(array( 'errorMsg' => '课程还未发布,不能评价!'));
        }

        $learns = $this->getCourseService()->getUserLearnLessonStatuses($user['id'], $id);
        if (!$learns) {
            return $this->createJsonResponse(array( 'errorMsg' => '还未学过该课程,不允许进行评价!'));
        }
 
        $fields = $request->request->all();
        $fields['userId']= $user['id'];
        $fields['courseId']= $id;
        $this->getReviewService()->saveReview($fields);

        return $this->createJsonResponse(true);
    }

    protected function getReviewService()
    {
        return $this->getServiceKernel()->createService('Course.ReviewService');
    }

}