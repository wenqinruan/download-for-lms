<?php
namespace Custom\WebBundle\Controller;

use Topxia\WebBundle\Controller\LessonNotePluginController as ParentController;
use Symfony\Component\HttpFoundation\Request;

class LessonNotePluginController extends ParentController
{
    public function saveAction(Request $request)
    {
        $form = $this->createNoteForm();
        if ($request->getMethod() == 'POST') {
            $form->bind($request);
            if ($form->isValid()) {
                $note = $form->getData();
                $note['status'] = $request->request->get('status') ? 1 : 0;
                $this->getCourseNoteService()->saveNote($note);

                return $this->createJsonResponse(true);
            } else {
                return $this->createJsonResponse(false);
            }
        }

        return $this->createJsonResponse(false);
    }

    public function initAction(Request $request)
    {
        $user = $this->getCurrentUser();
        if (!$user->isLogin()) {
            throw $this->createAccessDeniedException();
        }

        $lessonId = $request->query->get('lessonId');
        $permission = $this->getCourseService()->accessLesson($lessonId);
        if (!$permission['status']) {
            return $this->render('CustomWebBundle:LessonNotePlugin:denied.html.twig');
        }

        $course = $this->getCourseService()->getCourse($request->query->get('courseId'));
        $lesson = array('id' => $lessonId,'courseId' => $course['id']);
        $note = $this->getCourseNoteService()->getUserLessonNote($user['id'], $lesson['id']);
        $formInfo = array(
            'courseId' => $course['id'],
            'lessonId' => $lesson['id'],
            'content' => $note['content'],
            'id' => $note['id'],
        );
        $form = $this->createNoteForm($formInfo);

        return $this->render('TopxiaWebBundle:LessonNotePlugin:index.html.twig', array(
            'form' => $form->createView(),
            'note' => $note,
        ));
    }
}
