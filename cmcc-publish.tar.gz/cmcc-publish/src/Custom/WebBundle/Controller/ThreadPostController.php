<?php
namespace Custom\WebBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Topxia\WebBundle\Controller\BaseController;
use Topxia\Common\ArrayToolkit;
use Topxia\Common\Paginator;

class ThreadPostController extends BaseController
{
    public function listAction(Request $request, $target, $thread, $filter = array())
    {

        $posts = $this->getThreadService()->getThreadPosts(
            $threadId,
            $request->query->get('page', 1),
            $thread['commentCount']
        );

        $paginator = new Paginator(
            $request,
            100,
            10
        );
        
        $this->getThreadService()->hitThread($target['id'], $thread['id']);
        
        return $this->render("TopxiaWebBundle:Thread:show.html.twig", array(
            'target' => $target,
            'thread' => $thread,
            'author' => $this->getUserService()->getUser($thread['userId']),
            'posts' => $posts,
            'goodPosts' => $goodPosts,
            'users' => $users,
            'paginator' => $paginator,
            'service' => $this->getThreadService(),
        ));
    }
}