<?php
namespace Custom\WebBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Topxia\WebBundle\Controller\BaseController;

class FileController extends BaseController
{
    public function previewAction(Request $request, $id)
    {
        return $this->createJsonResponse("preview placeholder: {$id}");
    }
}
