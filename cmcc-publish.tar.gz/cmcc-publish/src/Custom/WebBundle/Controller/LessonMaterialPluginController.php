<?php
namespace Custom\WebBundle\Controller;

use Topxia\WebBundle\Controller\LessonMaterialPluginController as ParentController;
use Symfony\Component\HttpFoundation\Request;

class LessonMaterialPluginController extends ParentController
{

    public function initAction(Request $request)
    {
        $user = $this->getCurrentUser();
        if (!$user->isLogin()) {
            throw $this->createAccessDeniedException();
        }

        $lessonId = $request->query->get('lessonId');
        $courseId = $request->query->get('courseId');
        $permission = $this->getCourseService()->accessLesson($lessonId);
        if (!$permission['status']) {
            return $this->render('CustomWebBundle:LessonNotePlugin:denied.html.twig');
        }

        $course = $this->getCourseService()->getCourse($courseId);
        $lesson = $this->getCourseService()->getCourseLesson($course['id'], $lessonId);

        if ($lesson['mediaId'] > 0) {
            $file = $this->getUploadFileService()->getFile($lesson['mediaId']);
        } else {
            $file = null;
        }

        $lessonMaterials = $this->getMaterialService()->findLessonMaterials($lesson['id'], 0, 100);

        return $this->render('CustomWebBundle:LessonMaterialPlugin:index.html.twig', array(
            'materials' => $lessonMaterials,
            'course' => $course,
            'lesson' => $lesson,
            'preview' => $request->query->get('preview', false),
            'file' => $file,
        ));
    }

    public function downloadAction(Request $request, $courseId, $materialId)
    {

        $material = $this->getMaterialService()->getMaterial($courseId, $materialId);
        if (empty($material)) {
            throw $this->createNotFoundException();
        }

        if ($material['lessonId']) {
            $permission = $this->getCourseService()->accessLesson($material['lessonId']);
            if (!$permission['status']) {
                throw $this->createAccessDeniedException();
            }
        }

        $file = $this->getUploadFileService()->getFile($material['fileId']);
        if (empty($file)) {
            throw $this->createNotFoundException();
        }

        var_dump($file);exit();
        if ($file['storage'] == 'cloud') {
            $factory = new CloudClientFactory();
            $client = $factory->createClient();
            $client->download($client->getBucket(), $file['hashId'], 3600, $file['filename']);
        } else {
            return $this->createPrivateFileDownloadResponse($request, $file);
        }
    }
}
