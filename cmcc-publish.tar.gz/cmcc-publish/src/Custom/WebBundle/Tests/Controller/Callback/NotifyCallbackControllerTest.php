<?php

namespace Custom\WebBundle\Tests\Controller\Callback;

/**
 * 测试命令 $ phpunit -c app/phpunit_callback.xml --group notify
 */
class NotifyCallbackControllerTest extends BaseCallbackTestCase
{
    /**
     * @group notify
     */
    public function testItemDueNotifyAction()
    {
        $url = '/callback/item/due/notify';
        $params = array(
            'userIdentity' => 'f899139df5e1059396431415e770c6dd',
            'nickname' => '人心爱其',
            'itemName' => 'php高级课程',
        );

        $resp = $this->callApi($url, $params);
    }

    /**
     * @group notify
     */
    public function testidentificationNotifyAction()
    {
        $url = '/callback/teacher/identification/notify';
        $params = array(
            'userIdentity' => 'f899139df5e1059396431415e770c6dd',
            'status' => 'passed',
        );

        $resp = $this->callApi($url, $params);
    }
}
