<?php

namespace Custom\Service\User\Impl;

use Topxia\Service\User\Impl\UserServiceImpl as BaseUserServiceImpl;
use Custom\Service\User\UserService;
use Topxia\Common\ArrayToolkit;
use Custom\Service\CMCCApi\Convert;

class UserServiceImpl extends BaseUserServiceImpl implements UserService
{
    public function getUserByTokenId($tokenId)
    {
        return $this->getEManagerService()->getRemoteUserByTokenId($tokenId);
    }

    public function getUser($id, $lock = false)
    {
        return $remoteUsers = $this->getEManagerService()->getUser($id);
    }

    public function findUsersByIds(array $ids)
    {
        $users = $this->getEManagerService()->getUserList($ids);
        return ArrayToolkit::index($users, 'id');
    }

    public function searchTeachersByName($teacherName, $mcpId)
    {
        $teachers = $this->getEManagerService()->getTeacherListByName($teacherName, $mcpId);
        return $teachers;
    }

    public function updateContentTeacher($contentId, $professor, array $assistants)
    {
        
        return $this->getEManagerService()->updateContentTeacher($contentId, $professor, implode(',', $assistants)) ? true : false;
    }

    public function findMcpTeachers($mcpId, $start, $count)
    {
        $teachers = $this->getEManagerService()->getMcpTeacherList($mcpId, $start, $count);
        return $this->mcpTeacherSort($teachers);
    }

    protected function mcpTeacherSort(Array $teachers)
    {
        if (empty($teachers)) {
            return $teachers;
        }
        foreach ($teachers as $key => $value) {
            $teachers[$key]['userName'] = iconv('UTF-8', 'GBK//IGNORE', $value['userName']);
        }
        usort($teachers, function ($former, $latter) {
            if ($former['userName'] == $latter['userName']) {
                return 0;
            }
            return $former['userName'] > $latter['userName'] ? 1 : -1;
        });
        foreach ($teachers as $key => $value) {
            $teachers[$key]['userName'] = iconv('GBK', 'UTF-8//IGNORE', $value['userName']);
        }

        return $teachers;
    }

    public function waveUserCounter($userId, $field, $number)
    {
        return $this->waveState($userId, $field, $number);
    }

    public function clearUserCounter($userId, $field)
    {
        return $this->resetState($userId, $field);
    }

    public function getState($userId)
    {
        if ($this->hasState($userId)) {
            return $this->getUserStateDao()->getStateByUserId($userId);
        } else {
            $this->createState($userId);
            return $this->getUserStateDao()->getStateByUserId($userId);
        }
    }

    public function createState($userId)
    {
        $state = array(
            'userId' => $userId,
            'newMessageNum' => 0,
            'newNotificationNum' => 0
        );
        return $this->getUserStateDao()->createState($state);
    }

    public function hasState($userId)
    {
        $state = $this->getUserStateDao()->getStateByUserId($userId);
        if ($state) {
            return true;
        }
        return false;
    }

    public function waveState($userId, $field, $number)
    {
        if ($this->hasState($userId)) {
            return $this->getUserStateDao()->waveState($userId, $field, $number);
        } else {
            $this->createState($userId);
            return $this->getUserStateDao()->waveState($userId, $field, $number);
        }
    }

    public function resetState($userId, $field)
    {
        if (empty($field)) {
            return $this->getUserStateDao()->getStateByUserId($userId);
        }

        return $this->getUserStateDao()->updateState($userId, array($field => 0));
    }

    public function getUserProfile($id)
    {
        $user = $this->getUser($id);
        if ($user && isset($user['userProfile'])) {
            return $user['userProfile'];
        }
        return null;
    }

    protected function getUserStateDao()
    {
        return $this->createDao('Custom:User.UserStateDao');
    }

    public function findUserProfilesByIds(array $ids)
    {
        $users = $this->findUsersByIds($ids);
        $userProfiles = array();
        foreach ($users as $key => $value) {
            $userProfiles[$key] = $value['userProfile'];
        }
        return  ArrayToolkit::index($userProfiles, 'id');
    }

    public function makeToken($type, $userId = null, $expiredTime = null, $data = null)
    {
        $token = array();
        $token['type'] = $type;
        $token['userId'] = $userId ? $userId : 0;
        $token['token'] = base_convert(sha1(uniqid(mt_rand(), true)), 16, 36);
        $token['data'] = serialize($data);
        $token['expiredTime'] = $expiredTime ? (int) $expiredTime : 0;
        $token['createdTime'] = time();
        $token = $this->getUserTokenDao()->addToken($token);
        return $token['token'];
    }

    protected function getEManagerService()
    {
        return $this->createService('Custom:CMCCApi.EManagerService');
    }
}
