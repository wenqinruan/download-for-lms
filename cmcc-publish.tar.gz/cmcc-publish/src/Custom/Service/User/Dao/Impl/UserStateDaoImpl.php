<?php

namespace Custom\Service\User\Dao\Impl;

use Custom\Service\User\Dao\UserStateDao;
use Topxia\Service\Common\BaseDao;

class UserStateDaoImpl extends BaseDao implements UserStateDao
{
    protected $table = 'user_state';

    public function getState($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $sql = $this->modifyLimitQuery($sql, 1);

        return $this->fetchAssoc($sql, array($id)) ?: null;
    }

    public function getStateByUserId($userId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE userId = ?";
        $sql = $this->modifyLimitQuery($sql, 1);

        return $this->fetchAssoc($sql, array($userId)) ?: null;
    }

    public function createState($state)
    {
        $affected = $this->getConnection()->insert($this->table, $state);
        if ($affected <= 0) {
            throw $this->createDaoException('Insert user error.');
        }

        return $this->getState($this->lastInsertId());
    }

    public function waveState($userId, $field, $number)
    {
        $fields = array('newMessageNum', 'newNotificationNum');
        if (!in_array($field, $fields)) {
            throw $this->createDaoException('counter name error');
        }
        $sql = "UPDATE {$this->table} SET {$field} = {$field} + ? WHERE userId = ?";
        $sql = $this->modifyLimitQuery($sql, 1);

        return $this->getConnection()->executeQuery($sql, array($number, $userId));
    }

    public function updateState($userId, $fields)
    {
        $this->getConnection()->update($this->table, $fields, array('userId' => $userId));

        return $this->getStateByUserId($userId);
    }
}
