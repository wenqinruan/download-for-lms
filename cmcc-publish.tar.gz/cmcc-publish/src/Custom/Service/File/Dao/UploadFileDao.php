<?php

namespace Custom\Service\File\Dao;

interface UploadFileDao
{
    const TABLENAME = 'upload_files';

    public function findMediaFilesByCourseId($courseId,array $auditStatusList);

}