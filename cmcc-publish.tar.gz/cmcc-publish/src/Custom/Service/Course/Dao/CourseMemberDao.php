<?php
namespace Custom\Service\Course\Dao;

use Topxia\Service\Course\Dao\CourseMemberDao as BaseCourseMemberDao;

interface CourseMemberDao extends BaseCourseMemberDao
{
    public function findMembersByUserIdAndRoleAndStatus($userId, $role, $start, $limit, $courseStatus);

    public function findMemberCountByUserIdAndRoleAndStatus($userId, $role, $courseStatus);

    public function findLearnedCoursesByUserId($userId);
}
