<?php

namespace Custom\Service\Course\Dao\Impl;

use Custom\Service\Course\Dao\CourseDao;
use Topxia\Service\Course\Dao\Impl\CourseDaoImpl as BaseCourseDao;
use Custom\Service\File\Dao\UploadFileDao;

class CourseDaoImpl extends BaseCourseDao implements CourseDao
{
    protected $table = 'course';

    public function getCourseByNotPassedFileId($fileId)
    {
        $sql = 'SELECT c.* FROM '.UploadFileDao::TABLENAME." uf INNER JOIN {$this->table} c ON uf.targetType = 'courselesson' AND uf.auditStatus <> 'passed' AND uf.id = ? AND uf.targetId = c.id;";
        $sql .= ' ORDER BY c.createdTime DESC';
        $sql = $this->modifyLimitQuery($sql, 1);

        return $this->fetchAssoc($sql, array($fileId)) ?: null;
    }

    public function findCourseIdsByExtIds($exCourseIds)
    {
        if (empty($exCourseIds)) {
            return array();
        }
        $marks = str_repeat('?,', count($exCourseIds) - 1).'?';
        $sql = "SELECT id, extCourseId from {$this->table} WHERE extCourseId IN ({$marks})";

        return $this->fetchAll($sql, $exCourseIds);
    }

    public function findCoursesByExtIds($exCourseIds)
    {
        if (empty($exCourseIds)) {
            return array();
        }
        $marks = str_repeat('?,', count($exCourseIds) - 1).'?';
        $sql = "SELECT * from {$this->table} WHERE extCourseId IN ({$marks})";

        return $this->fetchAll($sql, $exCourseIds);
    }

    public function getCourseByExtId($extId)
    {
        $sql = "SELECT * from {$this->table} WHERE extCourseId = ?";
        $sql = $this->modifyLimitQuery($sql, 1);
        
        return $this->fetchAssoc($sql, array($extId)) ? : null;
    }
}
