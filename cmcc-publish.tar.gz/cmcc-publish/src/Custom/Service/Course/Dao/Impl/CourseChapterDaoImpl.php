<?php

namespace Custom\Service\Course\Dao\Impl;

use Custom\Service\Course\Dao\CourseChapterDao;
use Topxia\Service\Course\Dao\Impl\CourseChapterDaoImpl as BaseCourseChapterDao;

class CourseChapterDaoImpl extends BaseCourseChapterDao implements CourseChapterDao
{
    public function findChaptersByCourseIdAndType($courseId,$type)
    {
        $sql = "SELECT * FROM {$this->table} WHERE courseId = ? AND type= ?";
        return $this->fetchAll($sql,array($courseId,$type));
    }

    public function findChaptersByCourseIdAndTypeAndParentId($courseId, $type, $parentId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE  courseId = ? AND type = ? AND parentId = ?";
        return $this->fetchAll($sql,array($courseId,$type,$parentId));
    }
}
