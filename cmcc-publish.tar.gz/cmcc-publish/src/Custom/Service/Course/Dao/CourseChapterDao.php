<?php

namespace Custom\Service\Course\Dao;

interface CourseChapterDao
{
    public function findChaptersByCourseIdAndType($courseId,$type);

    public function findChaptersByCourseIdAndTypeAndParentId($courseId, $type, $parentId);

}
