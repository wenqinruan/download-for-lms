<?php

namespace Custom\Service\Course\Impl;

use Symfony\Component\Filesystem\Filesystem;
use Topxia\Service\Common\BaseService;
use Custom\Service\Course\CoursePackService;
use Custom\Common\Zip;

class CoursePackServiceImpl extends BaseService implements CoursePackService
{
    //压缩包的后缀
    protected $packageExt = '.ocf';

    protected static $fileSystem;

    public function buildPackage($courseId)
    {
        //生成未压缩的文件及目录结构
        $packageName = 'lms_course_'.$courseId;
        $modifiableFiles = $this->buildUnzipPackageStruct($packageName);

        //灌入数据
        foreach ($modifiableFiles as $key => $value) {
            $action = $this->formatFileNameToDumpAction($key);
            $this->$action($value, array('courseId' => $courseId));
        }

        //返回课程包本地路径
        return $this->zipPackage($packageName, $this->packageExt);
    }

    protected function formatFileNameToDumpAction($fileName)
    {
        $arr = explode('.', $fileName);
        $dumpAction = 'dump';
        foreach ($arr as $value) {
            $dumpAction .= ucfirst($value);
        }

        return $dumpAction;
    }

    protected function dumpContentOpf($path, array $options)
    {
        $rootNode = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?><package></package>');
        $rootNode->addAttribute('version', '2.0');
        $rootNode->addAttribute('unique-identifier', 'PrimaryID');
        $rootNode->addAttribute('xmlns', 'http://www.idpf.org/2007/opf');

        $metadataNode = $rootNode->addChild('metadata');
        foreach ($this->getCoursePackDataAdaptService()->getContentOpfMetadata($options['courseId']) as $key => $value) {
            $value = is_array($value) ? implode('|', $value) : $value;
            if ($value === null || $value === '') {
                $value = ' '; //防止出现<goals/>的情况
            } else {
                $value = trim($value);
            }
            if (in_array($key, array('longDescription'))) {
                $this->addCDATA($key, $value, $metadataNode);
            } else {
                $metadataNode->addChild($key, $value);
            }
        }
        //使用dom才能输出格式化的xml文件，simplexml输出都在一行
        $dom = dom_import_simplexml($rootNode)->ownerDocument;
        $dom->formatOutput = true;
        // echo $dom->saveXML();
        $dom->save($path);
        // $rootNode->saveXML($path);
    }

    protected function dumpContentNcx($path, array $options)
    {
        $rootNode = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?><ncx></ncx>');
        $rootNode->addAttribute('version', '2005-1');
        $rootNode->addAttribute('xmlns', 'http://www.daisy.org/z3986/2005/ncx/');

        $data = $this->getCoursePackDataAdaptService()->getContentNcxData($options['courseId']);
        $rootNode = $this->arrayToXml($data, $rootNode);

        $dom = dom_import_simplexml($rootNode)->ownerDocument;
        $dom->formatOutput = true;
        // echo $dom->saveXML();exit;
        // $dom->save($path);
        $dom->save($path);
    }

    protected function dumpCoverXml($path, array $options)
    {
        $rootNode = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?><cover></cover>');

        $course = $this->getCourseDao()->getCourse($options['courseId']);
        if (isset($course['largePicture'])) {
            $largeCover = $this->getContentFileService()->parseFileUri($course['largePicture']);
            $this->dumpCover($course['id'], $largeCover);
        }
        if (isset($course['middlePicture'])) {
            $middleCover = $this->getContentFileService()->parseFileUri($course['middlePicture']);
            $this->dumpCover($course['id'], $middleCover);
        }
        if (isset($course['smallPicture'])) {
            $smallCover = $this->getContentFileService()->parseFileUri($course['smallPicture']);
            $this->dumpCover($course['id'], $smallCover);
        }

        $coverData = $this->getCoursePackDataAdaptService()->getCoversData($largeCover['name'], $middleCover['name'], $smallCover['name']);

        $rootNode = $this->arrayToXml($coverData, $rootNode);
        $dom = dom_import_simplexml($rootNode)->ownerDocument;
        $dom->formatOutput = true;
        // echo $dom->saveXML();exit;
        // $dom->save($path);
        $dom->save($path);
    }

    protected function dumpCover($courseId, $cover)
    {
        $packagePath = $this->getFilePath().DIRECTORY_SEPARATOR.'lms_course_'.$courseId.DIRECTORY_SEPARATOR.'META-INF'.DIRECTORY_SEPARATOR.'ext';
        $destCover = $packagePath.DIRECTORY_SEPARATOR.'cover'.$cover['name'];
        $this->getFileSystem()->copy($cover['fullpath'], $destCover);
    }

    protected function dumpExt($path, array $options)
    {
    }

    /**
     * 创建压缩前空包的目录结构及必要文件.
     *
     * @param [string] $packageName [description]
     *
     * @return [array] [返回需要修改的文件及目录的绝对路径]
     */
    protected function buildUnzipPackageStruct($packageName)
    {
        //课程包内部结构模板，modify表示是否需要修改，content为该文件的默认内容
        $packageStruct = array(
            array('name' => 'mimetype', 'type' => 'file', 'modify' => 0,
                'content' => 'application/epub+zip/1.8', ),
            array('name' => 'META-INF', 'type' => 'dir', 'modify' => 0,
                'subDir' => array(
                    array('name' => 'content.opf', 'type' => 'file', 'modify' => 1),
                    array('name' => 'content.ncx', 'type' => 'file', 'modify' => 1),
                    array('name' => 'cover.xml', 'type' => 'file', 'modify' => 1),
                    array('name' => 'ext', 'type' => 'dir', 'modify' => 1),
                ),
            ),
        );

        $packagePath = $this->getFilePath().DIRECTORY_SEPARATOR.$packageName;

        //删除原有的包的目录
        $this->removePackage($packageName);

        //创建空包的目录
        $this->getFileSystem()->mkdir($packagePath);

        $flatPackageStruct = $this->flatPackageStructByName($packageStruct);

        //创建结构
        foreach ($flatPackageStruct as $value) {
            if (array_key_exists('path', $value)) {
                $value['name'] = $packagePath.DIRECTORY_SEPARATOR.$value['path'].DIRECTORY_SEPARATOR.$value['name'];
            } else {
                $value['name'] = $packagePath.DIRECTORY_SEPARATOR.$value['name'];
            }

            if ($value['type'] == 'dir') {
                $this->getFileSystem()->mkdir($value['name']);
            } elseif ($value['type'] == 'file') {
                //写入固定的内容
                if (array_key_exists('content', $value)) {
                    $this->getFileSystem()->dumpFile($value['name'], $value['content']);
                } else {
                    $this->getFileSystem()->touch($value['name']);
                }
            }
        }

        $modifiableFiles = array();
        foreach ($flatPackageStruct as $key => $value) {
            if ($value['modify']) {
                $modifiableFiles[$value['name']] = $packagePath.DIRECTORY_SEPARATOR.$value['path'].DIRECTORY_SEPARATOR.$value['name'];
            }
        }

        return $modifiableFiles;
    }

    /**
     * 删除课程包.
     *
     * @param [type] $packageName [description]
     *
     * @return [type] [description]
     */
    protected function removePackage($packageName)
    {
        $packagePath = $this->getFilePath().DIRECTORY_SEPARATOR.$packageName;
        if ($this->getFileSystem()->exists($packagePath)) {
            $this->getFileSystem()->remove($packagePath);
        }
    }

    /**
     * 压缩课程包.
     *
     * @param [type] $packageName          [description]
     * @param [type] $extension            [description]
     * @param bool   $isDeleteUnzipPackage [description]
     *
     * @return [type] [description]
     */
    protected function zipPackage($packageName, $extension = '.zip', $isDeleteUnzipPackage = true)
    {
        $packagePath = $this->getFilePath().DIRECTORY_SEPARATOR.$packageName;
        $zipPath = $packagePath.$extension;
        $this->removePackage($packageName.$extension);
        $zip = new Zip();
        if (true === $zip->open($zipPath, ZIP::CREATE)) {
            $zip->addDir($this->getFilePath(), $packageName, false);
            $zip->close();
            if ($isDeleteUnzipPackage) {
                $this->removePackage($packageName);
            }
        } else {
            throw $this->createServiceException("课程压缩包{$zipPath}创建失败");
        }

        return $zipPath;
    }

    /**
     * 包装多维数组成xml格式.
     *
     * @param array  $arrayData  [description]
     * @param [type] $parentNode [description]
     *
     * @return [type] [description]
     */
    protected function arrayToXml(array $arrayData, $parentNode)
    {
        foreach ($arrayData as $key => $value) {
            if (is_numeric($key)) {
                $currentNode = $parentNode->addChild($arrayData[$key]['node']);
                if (array_key_exists('attr', $value) && is_array($value['attr'])) {
                    foreach ($value['attr'] as $attrk => $attrv) {
                        $currentNode->addAttribute($attrk, ($attrv == null || $attrv == '') ? ' ' : $attrv);
                    }
                }
                if (array_key_exists('children', $value) && is_array($value['children'])) {
                    $currentNode = $this->arrayToXml($arrayData[$key]['children'], $currentNode);
                } elseif (array_key_exists('children', $value)) {
                    $currentNode->addChild('text', $arrayData[$key]['children']);
                }
            } else {
                if (in_array($key, array('fileContent'))) {
                    $currentNode = $this->addCDATA($key, $value, $parentNode);
                } else {
                    $currentNode = $parentNode->addChild($key, ($value == null || $value == '') ? ' ' : $value);
                }
            }
        }

        return $parentNode;
    }
    /**
     * 封装CDATA.
     *
     * @param [type] $name    [description]
     * @param [type] $value   [description]
     * @param [type] &$parent [description]
     */
    protected function addCDATA($name, $value, &$parent)
    {
        $child = $parent->addChild($name);

        if ($child !== null) {
            $child_node = dom_import_simplexml($child);
            $child_owner = $child_node->ownerDocument;
            $child_node->appendChild($child_owner->createCDATASection($value));
        }

        return $child;
    }

    /**
     * 在subDir的目录名前面加上上级目录路径，并把subDir全部拎到数组的第二维.
     *
     * @param [type] $packageStruct [description]
     *
     * @return [type] [description]
     */
    protected function flatPackageStructByName($packageStruct, $parentName = '')
    {
        static $res = array();
        foreach ($packageStruct as $key => $value) { //只遍历到第二维
            if ($value['type'] == 'dir' && array_key_exists('subDir', $value) && is_array($value['subDir'])) {
                $value['path'] = $parentName;
                unset($value['subDir']);
                $res[] = $value;
                $this->flatPackageStructByName($packageStruct[$key]['subDir'], ($parentName ? $parentName.DIRECTORY_SEPARATOR : '').$value['name']);
            } else {
                $value['path'] = $parentName;
                $res[] = $value;
            }
        }

        return $res;
    }

    protected function getFilePath($isPublic = false)
    {
        if ($isPublic) {
            $baseDirectory = $this->getKernel()->getParameter('topxia.upload.public_directory');
        } else {
            $baseDirectory = $this->getKernel()->getParameter('topxia.disk.local_directory');
        }
        $baseDirectory .= DIRECTORY_SEPARATOR.'coursepackage';

        if (!is_dir($baseDirectory)) {
            if (true !== @mkdir($baseDirectory, 0777, true)) {
                throw $this->createServiceException("根目录{$baseDirectory}创建失败，请检查目录权限");
            }
        } elseif (!is_writeable($baseDirectory)) {
            if (true !== @chmod($baseDirectory, 0777)) {
                throw $this->createServiceException("根目录{$baseDirectory}不可写");
            }
        }

        return $baseDirectory;
    }

    protected function getFileSystem()
    {
        if (!self::$fileSystem) {
            self::$fileSystem = new Filesystem();
        }

        return self::$fileSystem;
    }

    protected function getCoursePackDataAdaptService()
    {
        return $this->createService('Custom:Course.CoursePackDataAdaptService');
    }

    protected function getCourseDao()
    {
        return $this->createDao('Course.CourseDao');
    }

    protected function getContentFileService()
    {
        return $this->createService('Content.FileService');
    }

    protected function getCourseService()
    {
        return $this->createService('Custom:Course.CourseService');
    }
}
