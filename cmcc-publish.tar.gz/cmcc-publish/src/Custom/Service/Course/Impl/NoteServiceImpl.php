<?php
namespace Custom\Service\Course\Impl;

use Topxia\Service\Course\Impl\NoteServiceImpl as BaseNoteServiceImpl;
use Custom\Service\Course\Enum\LessonPermissions;
use Topxia\Common\ArrayToolkit;
use Topxia\Service\Common\ServiceEvent;

class NoteServiceImpl extends BaseNoteServiceImpl
{
    /**
     *类似这样的，提交数据保存到数据的流程是：
     *
     *  1. 检查参数是否正确，不正确就抛出异常
     *  2. 过滤数据
     *  3. 插入到数据库
     *  4. 更新其他相关的缓存字段
     */
    public function saveNote(array $note)
    {
        if (!ArrayToolkit::requireds($note, array('lessonId', 'courseId', 'content'))) {
            throw $this->createServiceException('缺少必要的字段，保存笔记失败');
        }

        $this->checkCreatePermission($note);
        
        if (!$this->getCourseService()->getCourseLesson($note['courseId'], $note['lessonId'])) {
            throw $this->createServiceException('课时不存在，保存笔记失败');
        }

        $note = ArrayToolkit::filter($note, array(
            'courseId' => 0,
            'lessonId' => 0,
            'content' => '',
            'status' => 0,
        ));

        $note['content'] = $this->purifyHtml($note['content']) ? : '';
        $note['length'] = $this->calculateContnentLength($note['content']);

        $user = $this->getCurrentUser();
        $existNote = $this->getUserLessonNote($user['id'], $note['lessonId']);
        if (!$existNote) {
            $note['userId'] = $user['id'];
            $note['createdTime'] = time();
            $note['updatedTime'] = time();
            $note = $this->getNoteDao()->addNote($note);
            $this->getDispatcher()->dispatch('course.note.create', new ServiceEvent($note));
        } else {
            $note['updatedTime'] = time();
            $note = $this->getNoteDao()->updateNote($existNote['id'], $note);
            $this->getDispatcher()->dispatch('course.note.update', new ServiceEvent($note, array('preStatus' => $existNote['status'])));
        }

        $this->getCourseService()->setMemberNoteNumber(
            $note['courseId'],
            $note['userId'],
            $this->getNoteDao()->getNoteCountByUserIdAndCourseId($note['userId'], $note['courseId'])
        );

        return $note;
    }

    public function like($noteId)
    {
        $user = $this->getCurrentUser();
        if (empty($user)) {
            throw $this->createNotFoundException("用户还未登录,不能点赞。", 1201);
        }

        $note = $this->getNote($noteId);
        if (empty($note)) {
            throw $this->createNotFoundException("笔记不存在，或已删除。", 1202);
        }

        $like = $this->getNoteLikeByNoteIdAndUserId($noteId, $user['id']);
        if (!empty($like)) {
            throw $this->createAccessDeniedException('不可重复对一条笔记点赞！', 1203);
        }

        $noteLike = array(
            'noteId' => $noteId,
            'userId' => $user['id'],
            'createdTime' => time(),
        );

        $this->getDispatcher()->dispatch('course.note.liked', new ServiceEvent($note));

        return $this->getNoteLikeDao()->addNoteLike($noteLike);
    }

    protected function checkCreatePermission($note)
    {
        $user = $this->getCurrentUser();
        if (!$user->isLogin()) {
            throw $this->createAccessDeniedException('需要登录');
        }

        $permission = $this->getCourseService()->checkLessonPermisson($note['lessonId'], LessonPermissions::ALLOWED_ACCESS_WITH_LOGIN, $user['id']);
        if (!$permission['status']) {
            throw $this->createAccessDeniedException($permission['errorMessage'], $permission['code']);
        }

    }
}