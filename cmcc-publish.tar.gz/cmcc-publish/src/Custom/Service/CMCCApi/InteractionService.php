<?php
namespace Custom\Service\CMCCApi;

/**
 * 互动平台API
 */
interface InteractionService
{
    /**
     * [getTopicList 获取课程下话题列表]
     * @param  [string] $conditions [conditions]
     * @param  [string] $sort       [sort]
     * @param  [string] $page       [页]
     * @param  [string] $count      [每页数量]
     * @return [array]  [description]
     */
    public function getTopicList($params, $sort, $page, $count);

    /**
     * [createTopic description]
     * @param  [type] $params [description]
     * @param  [type] $body   [description]
     * @return [type] [description]
     */
    public function createTopic($params, $body);

    public function editThread($params, $body);

    public function getTopic($courseId, $topicId);

    public function getPost($courseId, $postId);

    public function findThreadPosts($courseId, $topicId, $page, $count, $withReply);

    public function findPostReplys($courseId, $topicId, $postId, $page, $count);

    public function createPost($courseId, $topicId, $body);

    public function deletePost($postId);

    public function deletePostReply($replyId);

    public function createPostReply($fields);

    public function deleteThread($threadId);

    public function stickThread($threadId);

    public function unstickThread($threadId);

    public function eliteThread($threadId);

    public function uneliteThread($threadId);

    public function visitThread($threadId);

    public function createGroup($fields);

    public function findUserThreads($userId, $page, $count, $order, $type, $withComment);

    /**
     * [createReport 创建举报]
     * @param  [type] $type   [description]
     * @param  [type] $id     [description]
     * @param  [type] $reason [description]
     * @param  [type] $desc   [description]
     * @return [type]         [description]
     */
    public function createReport($type, $id, $reason, $desc);

    public function findThreadsByCourseIds($contentId, $page, $count, $order, $type, $withComment);

    public function findCourseReviews($courseId, $page, $count, $orderBy);

    public function createCourseReview($courseId, $fields);

    public function updateReview($reviewId, $fields);

    public function getReviewById($reviewId);

    public function getMyCourseReview($courseId);
    
}
