<?php
namespace Custom\Service\CMCCApi\Impl;

use Custom\Service\CMCCApi\BaseService;
use Custom\Service\CMCCApi\InteractionService;

class InteractionServiceImpl extends BaseService implements InteractionService
{
    protected $type = 'Interaction';

    public function getTopicList($params, $sort, $page, $count)
    {
        $apiMethodName = '/circle/topic/pagelist';

        $apiParams = array();

        if (!empty($params['extCourseId'])) {
            $apiParams['contentId'] = $params['extCourseId'];
        }

        if (!empty($params['lessonId'])) {
            $apiParamsp['lessonId'] = $params['lessonId'];
        }

        if (empty($params['type'])) {
            $apiParams['getType'] = 'all';
        } else {
            if ($params['type'] == 'question') {
                $apiParams['getType'] = 'onlyAsk';
            }
        }

        $apiParams['page'] = $page;
        $apiParams['count'] = $count;
        $apiParams['orderType'] = $sort;
        $apiParams['onlyHighLight'] = empty($params['isElite']) ? false : true;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        if (!empty($resp['result']['list'])) {
            return array($this->convertTopicList($resp['result']['list'], $params['courseId']), $resp['result']['totalCount']);
        }

        return array(array(), 0);
    }

    public function createTopic($params, $body)
    {
        $apiMethodName = '/circle/topic/create';

        $apiParams = array();
        $apiParams['contentId'] =  empty($params['extCourseId']) ? '' : $params['extCourseId'];
        if (!empty($params['lessonId'])) {
            $apiParams['lessonId'] = $params['lessonId'];
        }

        $apiParams['isAsk'] = empty($params['isAsk']) ? 'false' : 'true';

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');

        $this->verifyRespose($resp);

        return $this->convertTopic($resp['result'], $params['courseId']);
    }

    public function editThread($params, $body)
    {
        $apiMethodName = '/circle/topic/edit';

        $apiParams = array();
        $apiParams['topicId'] = $params['threadId'];

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');

        $this->verifyRespose($resp);

        return $this->convertTopic($resp['result'], $params['courseId']);
    }

    public function getTopic($courseId, $topicId)
    {
        $apiMethodName = '/circle/topic/info';

        $apiParams = array();
        $apiParams['topicId'] =  $topicId;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        return $this->convertTopic($resp['result'], $courseId);
    }

    public function getPost($courseId, $postId)
    {
        $apiMethodName = '/circle/comment/info';

        $apiParams = array();
        $apiParams['commentId'] =  $postId;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        return $this->convertPost($resp['result'], $courseId);
    }

    public function deletePost($postId)
    {
        $apiMethodName = '/circle/comment/delete';

        $apiParams = array();
        $apiParams['commentId'] =  $postId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');

        $this->verifyRespose($resp);
    }

    public function deleteThread($threadId)
    {
        $apiMethodName = '/circle/topic/delete';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');

        $this->verifyRespose($resp);
    }

    public function deletePostReply($replyId)
    {
        $apiMethodName = '/circle/reply/delete';

        $apiParams = array();
        $apiParams['replyId'] =  $replyId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');

        $this->verifyRespose($resp);
    }

    public function findThreadPosts($courseId, $topicId, $page, $count, $withReply)
    {
        $apiMethodName = '/circle/comment/pagelist';

        $apiParams = array();
        $apiParams['topicId'] =  $topicId;
        $apiParams['page'] =  $page;
        $apiParams['count'] =  $count;
        $apiParams['withReply'] =  $withReply;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        if (!empty($resp['result']['list'])) {
            return $this->convertPosts($resp['result']['list'], $courseId);
        }

        return array();
    }

    public function findPostReplys($courseId, $topicId, $postId, $page, $count)
    {
        $apiMethodName = '/circle/reply/pagelist';

        $apiParams = array();
        $apiParams['commentId'] =  $postId;
        $apiParams['page'] =  $page;
        $apiParams['count'] =  $count;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        return $this->convertReplys($resp['result']['list'], $courseId, $topicId);
    }

    public function createPost($courseId, $topicId, $body)
    {
        $apiMethodName = '/circle/comment/create';

        $apiParams = array();
        $apiParams['topicId'] =  $topicId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');

        $this->verifyRespose($resp);

        return $this->convertPost($resp['result'], $courseId);
    }

    public function createPostReply($fields)
    {
        $apiMethodName = '/circle/reply/create';

        $apiParams = array();
        $apiParams['commentId'] =  $fields['postId'];

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $body = array();
        $body['content'] = $fields['content'];
        if (!empty($fields['replyToUser'])) {
            $body['replyToUser'] = $fields['replyToUser'];
        }

        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');
        $this->verifyRespose($resp);

        return $this->convertReply($resp['result'], $fields['courseId'], $fields['threadId']);
    }

    public function stickThread($threadId)
    {
        $apiMethodName = '/circle/topic/settop';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');
        $this->verifyRespose($resp);
    }

    public function unstickThread($threadId)
    {
        $apiMethodName = '/circle/topic/canceltop';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');
        $this->verifyRespose($resp);
    }

    public function eliteThread($threadId)
    {
        $apiMethodName = '/circle/topic/highlight';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');

        $this->verifyRespose($resp);
    }

    public function uneliteThread($threadId)
    {
        $apiMethodName = '/circle/topic/cancelhighlight';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');
        $this->verifyRespose($resp);
    }

    public function visitThread($threadId)
    {
        $apiMethodName = '/circle/topic/visit';

        $apiParams = array();
        $apiParams['topicId'] =  $threadId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');
        $this->verifyRespose($resp);
    }

    public function createGroup($fields)
    {
        $apiMethodName = '/circle/circle/autoCreateCircle';

        $authCode = 'SDF213$#@$SAas1=';
        $encryptedCode = base64_encode(md5($authCode));

        $headers = array();
        $headers[] = "authCode: {$encryptedCode}";

        $resp = $this->createApiClient()->execute($apiMethodName, $fields, 'POST', $headers);
        $this->verifyRespose($resp);

        return $resp;
    }

    public function findUserThreads($userId, $page, $count, $order, $type, $withComment)
    {
        $apiMethodName = '/circle/topic/listforuser';

        $apiParams = array();
        //$apiParams['userId'] =  $userId;//userId需要一致,不然会报错,现在暂时先不传入
        $apiParams['page'] =  $page;
        $apiParams['count'] =  $count;
        $apiParams['orderType'] =  $order;
        $apiParams['getType'] =  $type;
        $apiParams['withComment'] =  $withComment;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        //硬编码课程Id,后面互动那边的帖子必须有课程Id
        if (!empty($resp['result']['list'])) {
            return array($this->convertTopicList($resp['result']['list'], 0), $resp['result']['totalCount']);
        }

        return array(array(), 0);
    }

    public function createReport($type, $destId, $reason, $desc)
    {
        $apiMethodName = '/circle/reportbad/create';

        $apiParams = array();
        $apiParams['type'] =  $type;
        $apiParams['destId'] =  $destId;
        $apiParams['reason'] =  $reason;
        $apiParams['desc'] =  $desc;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'POST');
        $this->verifyRespose($resp);
        
        return $resp;
    }

    public function findThreadsByCourseIds($contentId, $page, $count, $order, $type, $withComment)
    {
        $apiMethodName = '/circle/topic/multilist';

        $apiParams = array();
        $apiParams['contentId'] =  $contentId;
        $apiParams['page'] =  $page;
        $apiParams['count'] =  $count;
        $apiParams['orderType'] =  $order;
        $apiParams['getType'] =  $type;
        $apiParams['withComment'] =  $withComment;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        if (!empty($resp['result']['list'])) {
            return array($this->convertTopicList($resp['result']['list'], 0), $resp['result']['totalCount']);
        }

        return array(array(), 0);
    }

    public function getReviewById($reviewId)
    {
        $apiMethodName = '/circle/course/comment/info';

        $apiParams = array();
        $apiParams['commentId'] =  $reviewId;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        return $this->convertReview($resp['result']);
    }

    public function getMyCourseReview($courseId)
    {
        $apiMethodName = '/circle/course/comment/getmy';

        $apiParams = array();
        $apiParams['courseId'] =  $courseId;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        //接口用户评价为空会返回404,所以暂时注释掉
        //$this->verifyRespose($resp);

        return $this->convertReview($resp['result']);
    }

    public function findCourseReviews($courseId, $page, $count, $orderBy = 'publishTime')
    {
        $apiMethodName = '/circle/course/comment/list';

        $apiParams = array();
        $apiParams['courseId'] =  $courseId;
        $apiParams['page'] =  $page;
        $apiParams['count'] =  $count;
        $apiParams['orderType'] =  $orderBy;

        $resp = $this->createApiClient()->execute($apiMethodName, $apiParams, 'GET');

        $this->verifyRespose($resp);

        if (!empty($resp['result']['list'])) {
            return array($this->convertReviews($resp['result']['list'], 0), $resp['result']['totalCount']);
        }

        return array(array(), 0);
    }

    public function createCourseReview($courseId, $fields)
    {
        $apiMethodName = '/circle/course/comment/create';

        $apiParams = array();
        $apiParams['courseId'] =  $courseId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $body = array();
        $body['content'] = $fields['content'];
        $body['score1'] = $fields['rating'];
        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');
        $this->verifyRespose($resp);

        return $this->convertReview($resp['result']);
    }

    public function updateReview($reviewId, $fields)
    {
        $apiMethodName = '/circle/course/comment/edit';

        $apiParams = array();
        $apiParams['commentId'] =  $reviewId;

        $apiMethodName = $apiMethodName.'?'.http_build_query($apiParams);

        $body = $fields;
        $body['content'] = $fields['content'];
        $body['score1'] = $fields['rating'];
        $resp = $this->createApiClient()->execute($apiMethodName, $body, 'POST');
        $this->verifyRespose($resp);

        return $this->convertReview($resp['result']);
    }

    public function convertReviews($reviews)
    {
        if (empty($reviews)) {
            return array();
        }
        $new = array();
        foreach ($reviews as $review) {
            $new[] = $this->convertReview($review);
        }

        return $new;
    }

    public function convertReview($review)
    {
        if (empty($review)) {
            return;
        }

        $review['rating'] = $review['score1'];
        $review['owner']['smallAvatar'] = $review['owner']['userIcon'];
        $review['userId'] = $review['owner']['id'];
        $review['createdTime'] = intval($review['publishTime']/1000);
        return $review;
    }

    protected function convertTopicList($list, $courseId)
    {
        if (empty($list)) {
            return;
        }
        $newList = array();
        foreach ($list as $topic) {
            $newList[] = $this->convertTopic($topic, $courseId);
        }

        return $newList;
    }

    protected function convertTopic($topic, $courseId)
    {
        if (empty($topic)) {
            return;
        }

        $topic['owner']['smallAvatar'] = $topic['owner']['userIcon'];
        $topic['courseId'] = $topic['courseId'];
        $topic['type'] = $topic['ask'] ? 'question' : 'discussion';
        $topic['sticky'] = $topic['top'];
        $topic['nice'] = $topic['highLight'];
        $topic['userId'] = $topic['owner']['id'];
        $topic['postNum'] = $topic['totalReplyCount'];
        $topic['isElite'] = $topic['highLight'] ? 1 : 0;
        $topic['hitNum'] = 0;
        $topic['createdTime'] = intval($topic['publishTime']/1000);
        $topic['lastReplyTime'] = intval($topic['lastReplyTime']/1000);

        if ($topic['newComments']) {
            $topic['lastPost'] = $topic['newComments'][0];
        }

        return $topic;
    }

    protected function convertPosts($posts, $courseId)
    {
        $new = array();
        foreach ($posts as $post) {
            $new[] = $this->convertPost($post, $courseId);
        }

        return $new;
    }

    protected function convertPost($post, $courseId)
    {
        if (empty($post)) {
            return;
        }

        $post['owner']['smallAvatar'] = $post['owner']['userIcon'];
        $post['courseId'] = $courseId;
        $post['threadId'] = $post['topicId'];
        $post['userId'] = $post['owner']['userId'];
        $post['createdTime'] = intval($post['publishTime']/1000);

        return $post;
    }

    protected function convertReplys($replys, $courseId, $threadId)
    {
        $new = array();
        foreach ($replys as $reply) {
            $new[] = $this->convertReply($reply, $courseId, $threadId);
        }

        return $new;
    }

    protected function convertReply($reply, $courseId, $threadId)
    {
        if (empty($reply)) {
            return;
        }

        $reply['owner']['smallAvatar'] = $reply['owner']['userIcon'];
        $reply['courseId'] = $courseId;
        $reply['threadId'] = $threadId;
        $reply['postId'] = $reply['commentId'];
        $reply['userId'] = $reply['owner']['userId'];
        $reply['createdTime'] = intval($reply['publishTime']/1000);
        $reply['ats'] = array();
        if (!empty($reply['userToReply']) && !empty($reply['nickname'])) {
            $reply['ats'][$reply['userToReply']['nickname']] = $reply['userToReply']['id'];
        }

        return $reply;
    }
}
