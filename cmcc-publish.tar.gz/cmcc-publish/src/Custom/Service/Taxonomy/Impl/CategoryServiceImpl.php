<?php
namespace Custom\Service\Taxonomy\Impl;

use Csutom\Service\Taxonomy\CategoryService;
use Topxia\Service\Common\BaseService;
use Topxia\Common\ArrayToolkit;
use Topxia\Service\Taxonomy\Impl\CategoryServiceImpl as ParentServiceImpl;

class CategoryServiceImpl extends ParentServiceImpl implements CategoryService
{
    public function getCategory($id)
    {
        return $this->getEManagerService()->getCategoryById($id);
    }

    protected function getEManagerService()
    {
        return $this->createService('Custom:CMCCApi.EManagerService');
    }
}
