<?php

namespace Topxia\Service\Util\Dao;

interface SystemUtilDao
{
   public function getCourseIdsWhereCourseHasDeleted();

}