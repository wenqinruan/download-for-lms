<?php
namespace Topxia\Service\Common;

use \Exception;

class ServiceException extends Exception
{

}