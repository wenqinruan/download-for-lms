<?php

namespace Topxia\Service\Taxonomy\Dao\Impl;

use Topxia\Service\Common\BaseDao;
use Topxia\Service\Taxonomy\Dao\CategoryGroupDao;

class CategoryGroupDaoImpl extends BaseDao implements CategoryGroupDao
{
    protected $table = 'category_group';

    public function getGroup($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $sql = $this->modifyLimitQuery($sql, 1);
        return $this->fetchAssoc($sql, array($id));
    }

    public function findGroupByCode($code)
    {
        $sql = "SELECT * FROM {$this->table} WHERE code = ?";
        $sql = $this->modifyLimitQuery($sql, 1);

        return $this->fetchAssoc($sql, array($code));
    }

    public function findGroups($start, $limit)
    {
        $this->filterStartLimit($start, $limit);
        $sql = "SELECT * FROM {$this->table}";
        $sql = $this->modifyLimitQuery($sql, $limit, $start);

        return $this->fetchAll($sql, array()) ? : array();
    }

    public function findAllGroups()
    {
        $sql = "SELECT * FROM {$this->table}";
        return $this->fetchAll($sql) ? : array();
    }

    public function addGroup(array $group)
    {
        $affected = $this->getConnection()->insert($this->table, $group);
        if ($affected <= 0) {
            throw $this->createDaoException('Insert group error.');
        }
        return $this->getGroup($this->lastInsertId());
    }

    public function deleteGroup($id)
    {
        return $this->getConnection()->delete($this->table, array('id' => $id));
    }
}