<?php

namespace Topxia\Component\MediaParser\AlbumParser;

use Topxia\Component\MediaParser\AbstractParser;

abstract class AbstractAlbumParser extends AbstractParser
{

}