<?php

namespace Topxia\WebBundle\Extensions\DataTag\Test;

use Topxia\Service\Common\BaseTestCase;
use Topxia\WebBundle\Extensions\DataTag\CourseBaseDataTag;

class CourseBaseDataTagTest extends BaseTestCase
{   

    public function testGetData()
    {

    }

}