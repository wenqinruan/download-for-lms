<?php
namespace Topxia\MobileBundleV2\Processor;

interface MobileProcessor
{
	public function autoLogin();
}