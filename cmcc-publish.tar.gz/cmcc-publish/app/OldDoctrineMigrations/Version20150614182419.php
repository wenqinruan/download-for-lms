<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;
use Doctrine\DBAL\Schema\Column;
use Doctrine\DBAL\Schema\ColumnDiff;
use Doctrine\DBAL\Schema\TableDiff;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150614182419 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs
        //重命名number字段
        $platform = $this->connection->getDatabasePlatform();
        $newColumn = new Column('no', Type::getType('integer'), array(
            'length' => 10,
            'default' => 0,
            'notnull' => true,
            'unsigned' => true,
            'comment' => '章节序号'
        ));
        $ColumnDiff = new ColumnDiff('number', $newColumn);
        $tableDiff = new TableDiff('course_chapter', array(), array('number' => $ColumnDiff));
        $sqls = $platform->getAlterTableSQL($tableDiff);
        foreach ($sqls as $key => $sql) {
            $this->addSql($sql);
        }

        //重命名number字段
        $platform = $this->connection->getDatabasePlatform();
        $newColumn = new Column('no', Type::getType('integer'), array(
            'length' => 10,
            'default' => 0,
            'notnull' => true,
            'unsigned' => true,
            'comment' => '课时序号'
        ));
        $ColumnDiff = new ColumnDiff('number', $newColumn);
        $tableDiff = new TableDiff('course_lesson', array(), array('number' => $ColumnDiff));
        $sqls = $platform->getAlterTableSQL($tableDiff);
        foreach ($sqls as $key => $sql) {
            $this->addSql($sql);
        }

        //重命名number字段
        $platform = $this->connection->getDatabasePlatform();
        $newColumn = new Column('no', Type::getType('integer'), array(
            'length' => 10,
            'default' => 0,
            'notnull' => true,
            'unsigned' => true,
            'comment' => '序号'
        ));
        $ColumnDiff = new ColumnDiff('number', $newColumn);
        $tableDiff = new TableDiff('user_fortune_log', array(), array('number' => $ColumnDiff));
        $sqls = $platform->getAlterTableSQL($tableDiff);
        foreach ($sqls as $key => $sql) {
            $this->addSql($sql);
        }
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
