<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150706112110 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs

        $message = $schema->getTable('message');
        $message->addColumn('type', 'string', array(
            'length' => 32,
            'default' => 'text',
            'notnull' => true,
            'comment' => '私信类型',
        ));

        $message_conversation = $schema->getTable('message_conversation');
        $message_conversation->addColumn('latestMessageType', 'string', array(
            'length' => 32,
            'default' => 'text',
            'notnull' => true,
            'comment' => '最后一条私信类型',
        ));

    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
