<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150724134149 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs
        $classroom_review = $schema->getTable('classroom_review');
        $classroom_review->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $comments = $schema->getTable('comments');
        $comments->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $content = $schema->getTable('content');
        $content->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $coupon = $schema->getTable('coupon');
        $coupon->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course = $schema->getTable('course');
        $course->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_draft = $schema->getTable('course_draft');
        $course_draft->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_favorite = $schema->getTable('course_favorite');
        $course_favorite->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_lesson = $schema->getTable('course_lesson');
        $course_lesson->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_lesson_learn = $schema->getTable('course_lesson_learn');
        $course_lesson_learn->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_lesson_view = $schema->getTable('course_lesson_view');
        $course_lesson_view->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_material = $schema->getTable('course_material');
        $course_material->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_member = $schema->getTable('course_member');
        $course_member->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_lesson_replay = $schema->getTable('course_lesson_replay');
        $course_lesson_replay->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_note = $schema->getTable('course_note');
        $course_note->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_note_like = $schema->getTable('course_note_like');
        $course_note_like->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_review = $schema->getTable('course_review');
        $course_review->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_thread = $schema->getTable('course_thread');
        $course_thread->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $course_thread_post = $schema->getTable('course_thread_post');
        $course_thread_post->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $files = $schema->getTable('files');
        $files->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $friend = $schema->getTable('friend');
        $friend->changeColumn('fromId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $friend = $schema->getTable('friend');
        $friend->changeColumn('toId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups = $schema->getTable('groups');
        $groups->changeColumn('ownerId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_member = $schema->getTable('groups_member');
        $groups_member->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_thread = $schema->getTable('groups_thread');
        $groups_thread->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_thread_collect = $schema->getTable('groups_thread_collect');
        $groups_thread_collect->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_thread_goods = $schema->getTable('groups_thread_goods');
        $groups_thread_goods->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_thread_post = $schema->getTable('groups_thread_post');
        $groups_thread_post->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $groups_thread_trade = $schema->getTable('groups_thread_trade');
        $groups_thread_trade->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $log = $schema->getTable('log');
        $log->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $message = $schema->getTable('message');
        $message->changeColumn('fromId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $message = $schema->getTable('message');
        $message->changeColumn('toId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $message_conversation = $schema->getTable('message_conversation');
        $message_conversation->changeColumn('fromId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $message_conversation = $schema->getTable('message_conversation');
        $message_conversation->changeColumn('toId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $money_card = $schema->getTable('money_card');
        $money_card->changeColumn('rechargeUserId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $money_card_batch = $schema->getTable('money_card_batch');
        $money_card_batch->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $money_record = $schema->getTable('money_record');
        $money_record->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $notification = $schema->getTable('notification');
        $notification->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $orders = $schema->getTable('orders');
        $orders->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $order_log = $schema->getTable('order_log');
        $order_log->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $order_refund = $schema->getTable('order_refund');
        $order_refund->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $question = $schema->getTable('question');
        $question->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $question_category = $schema->getTable('question_category');
        $question_category->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $question_favorite = $schema->getTable('question_favorite');
        $question_favorite->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $session2 = $schema->getTable('session2');
        $session2->changeColumn('user_id', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $shortcut = $schema->getTable('shortcut');
        $shortcut->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $sign_card = $schema->getTable('sign_card');
        $sign_card->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $sign_user_log = $schema->getTable('sign_user_log');
        $sign_user_log->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $sign_user_statistics = $schema->getTable('sign_user_statistics');
        $sign_user_statistics->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $status = $schema->getTable('status');
        $status->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $testpaper = $schema->getTable('testpaper');
        $testpaper->changeColumn('createdUserId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $testpaper = $schema->getTable('testpaper');
        $testpaper->changeColumn('updatedUserId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $testpaper_item_result = $schema->getTable('testpaper_item_result');
        $testpaper_item_result->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $testpaper_result = $schema->getTable('testpaper_result');
        $testpaper_result->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $thread = $schema->getTable('thread');
        $thread->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $thread_member = $schema->getTable('thread_member');
        $thread_member->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $thread_post = $schema->getTable('thread_post');
        $thread_post->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $thread_vote = $schema->getTable('thread_vote');
        $thread_vote->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $upload_files = $schema->getTable('upload_files');
        $upload_files->changeColumn('updatedUserId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $upload_files = $schema->getTable('upload_files');
        $upload_files->changeColumn('createdUserId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $user_approval = $schema->getTable('user_approval');
        $user_approval->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $user_fortune_log = $schema->getTable('user_fortune_log');
        $user_fortune_log->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $user_secure_question = $schema->getTable('user_secure_question');
        $user_secure_question->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $user_token = $schema->getTable('user_token');
        $user_token->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $vip = $schema->getTable('vip');
        $vip->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));

        $vip_history = $schema->getTable('vip_history');
        $vip_history->changeColumn('userId', array(
            'type' => Type::getType('string'),
            'length' => 128,
            'default' => '',
            'notnull' => true,
        ));
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
