<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150622090205 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs

        $table = $schema->getTable('upload_files');
        //$this->addSql("ALTER TABLE `course` ADD `auditStatus` enum('unsubmitted', 'submitted', 'rejected', 'passed') NOT NULL DEFAULT 'unsubmitted' COMMENT '课程审核状态' AFTER `status`;");
        $table->addColumn('auditStatus','enum',array(
            'default'=>'unsubmitted',
            'notnull'=> true,
            'comment'=>'unsubmitted,submitted,rejected,passed',

        ));

    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
