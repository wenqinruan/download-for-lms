<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150630200940 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        $orders = $schema->getTable('orders');
        $orders->changeColumn('payment', array(
            'type' => Type::getType('enum'),
            'default' => 'none',
            'notnull' => false,
            'comment' => 'none,alipay,tenpay,coin,wxpay',
        ));

        $cash_orders = $schema->getTable('cash_orders');
        $cash_orders->changeColumn('payment', array(
            'type' => Type::getType('enum'),
            'default' => 'none',
            'notnull' => false,
            'comment' => 'none,alipay,tenpay,coin,wxpay',
        ));

        $cash_flow = $schema->getTable('cash_flow');
        $cash_flow->addColumn('payment', 'enum', array(
            'notnull'=> false,
            'comment' => 'alipay,wxpay'
        ));

    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
