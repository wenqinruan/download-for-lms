<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150615155302 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        $table = $schema->getTable('COURSE');
        // this up() migration is auto-generated, please modify it to your needs
        //$this->addSql("ALTER TABLE `course` ADD `auditStatus` enum('unsubmitted', 'submitted', 'rejected', 'passed') NOT NULL DEFAULT 'unsubmitted' COMMENT '课程审核状态' AFTER `status`;");
        $table->addColumn('auditStatus','enum',array(
            'default'=>'unsubmitted',
            'notnull'=> true,
            'comment'=>'unsubmitted,submitted,rejected,passed',
            ));
        //$this->addSql("ALTER TABLE `course` ADD `hasLiveLesson` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否包含直播课时' AFTER `lessonNum`;");
        $table->addColumn('hasLiveLesson','integer',array(
            'unsigned'=>true,
            'default'=>0,
            'length'=> '3',
            'notnull'=> true,
            'comment'=>'是否包含直播课时'
            ));
        //$this->addSql("ALTER TABLE `course` ADD `hasVideoLesson` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否包含视频课时' AFTER `hasLiveLesson`;");
        $table->addColumn('hasVideoLesson','integer',array(
            'unsigned'=>true,
            'default'=>0,
            'length'=> '3',
            'notnull'=> true,
            'comment'=>'是否包含视频课时'          
            ));
        $table->addColumn('keyword','string', array (
              'default' => NULL,
              'notnull' => false,
              'length' => '255',
              'precision' => 10,
              'scale' => 0,
              'fixed' => false,
              'unsigned' => false,
              'autoincrement' => false,
              'columnDefinition' => NULL,
              'comment' => '',
              'customSchemaOptions' => 
              array (
                'collate' => 'utf8_general_ci',
              ),
            ));
        $table->addColumn('publishedTime','integer', array (
              'default' => '0',
              'notnull' => true,
              'length' => '10',
              'precision' => 10,
              'scale' => 0,
              'fixed' => false,
              'unsigned' => true,
              'autoincrement' => false,
              'columnDefinition' => NULL,
              'comment' => '',
            )); 
        $table->addColumn('shortRecommendReason','integer', array (
              'default' => '0',
              'notnull' => true,
              'length' => '10',
              'precision' => 10,
              'scale' => 0,
              'fixed' => false,
              'autoincrement' => false,
              'columnDefinition' => NULL,
              'comment' => '',
            ));       
        // $this->addSql("ALTER TABLE `course` ADD COLUMN `keyword` varchar(255) COMMENT '' AFTER `subtitle`;");
        // $this->addSql("ALTER TABLE `course` ADD COLUMN `publishedTime` int(10) UNSIGNED DEFAULT '0' COMMENT '' AFTER `createdTime`;");
        // $this->addSql("ALTER TABLE `course` ADD COLUMN `shortRecommendReason` int(10) COMMENT '' AFTER `subtitle`;");
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {

    }
}
