<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150630150851 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        //$this->addSql("ALTER TABLE `course` ADD COLUMN `hasAudioLesson` tinyint(3) UNSIGNED NOT NULL COMMENT '是否包含音频课时' AFTER `hasLiveLesson`;");
        $course = $schema->getTable('course');
        $course->addColumn('hasAudioLesson', 'smallint', array(
            'unsigned' => true,
            'default' => 0,
            'length' => 1,
            'notnull' => true,
            'comment' => '是否包含音频课时',
        ));
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
