<?php

namespace Application\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
class Version20150705210151 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        //$this->addSql("ALTER TABLE `course_audit_log` RENAME TO `audit_log`;");
        $schema->renameTable('course_audit_log', 'audit_log');
        //$this->addSql("ALTER TABLE `audit_log` ADD COLUMN `direction` enum('send','receive') NOT NULL AFTER `targetType` COMMENT '请求方向，发送或接收';");
        $audit_log = $schema->getTable('audit_log');
        $audit_log->addColumn('direction', 'enum', array(
            'default' => 'send',
            'notnull' => true,
            'comment' => 'send,receive',
        ));

        //$this->addSql("ALTER TABLE `audit_log` CHANGE COLUMN `status` `status` enum('submitted','rejected','passed') NOT NULL COMMENT '审核结果';");
        $audit_log->changeColumn('status', array(
            'type' => Type::getType('enum'),
            'default' => 'submitted',
            'notnull' => true,
            'comment' => 'submitted,rejected,passed',
        ));

        //$this->addSql("ALTER TABLE `course` CHANGE COLUMN `hasAudioLesson` `hasAudioLesson` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否包含音频课时';");
        $course = $schema->getTable('course');
        $course->changeColumn('hasAudioLesson', array(
            'type' => Type::getType('smallint'),
            'unsigned' => true,
            'default' => 0,
            'length' => 1,
            'notnull' => true,
            'comment' => '是否包含音频课时',
        ));
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs

    }
}
