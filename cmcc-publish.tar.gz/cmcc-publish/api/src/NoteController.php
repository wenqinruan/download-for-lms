<?php


$api = $app['controllers_factory'];

/**
 * 保存笔记
 */
$api->post('/', function () use ($app) {
    $note = $app['note.service']->saveNote();

    return array('data' => $note);
});

/**
 * 获取笔记
 */
$api->get('/', function () use ($app) {
    $response = $app['note.service']->searchNotes();

    return $response;
});

/**
 * 笔记点赞
 */
$api->post('/{id}/likes', function ($id) use ($app) {

    $app['note.service']->like($id);

    return array();
});

/**
 * 笔记取消点赞
 */
$api->delete('/{id}/likes', function ($id) use ($app) {
    $app['note.service']->cancelLike($id);

    return array();
});

$api->post('/images', function () use ($app) {
    return $app['note.service']->upload();
});

return $api;
