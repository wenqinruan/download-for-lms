<?php


$api = $app['controllers_factory'];

/**
 * 获取某一课时的学习状态
 */
$api->get('/{id}/learn_status', function ($id) use ($app) {
    return $app['lesson.service']->getUserLearnStatus($id);
});

/**
 * 完成某一课时的学习
 */
$api->post('/{id}/learned', function ($id) use ($app) {
    return $app['lesson.service']->finishLearnLesson($id);
});

/**
 * 取消某一课时的学习
 */
$api->delete('/{id}/learned', function ($id) use ($app) {
    return $app['lesson.service']->cancelLearnLesson($id);
});

/**
 * 开始学习某课时
 */
$api->post('/{id}/learning', function ($id) use ($app) {
    return $app['lesson.service']->startLearnLesson($id);
});

return $api;
