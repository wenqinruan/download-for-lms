<?php
namespace CmccApi\Service\Impl;

use CmccApi\Service\BaseService;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * LessonService errorcode prefix 11
 */
class LessonServiceImpl extends BaseService
{
    
    public function getUserLearnStatus($lessonId)
    {
        $user = getCurrentUser();
        $status = createService('Custom:Course.CourseService')->getUserLearnLessonStatus($user['id'], 0, $lessonId);
        $response = array(
            'learnStatus' => 'not-started'
        );
        if (!empty($status)) {
            $response['learnStatus'] = $status;
        }
        return $response;
    }

    public function finishLearnLesson($lessonId)
    {
        $lesson = createService('Custom:Course.CourseService')->getLesson($lessonId);
        $course = createService('Custom:Course.CourseService')->getCourse($lesson['courseId']);
        if (empty($course)) {
            throw new AccessDeniedHttpException("Id为{$courseId}的课程不存在", null, 1001);
        }

        if (empty($lesson)) {
            throw new AccessDeniedHttpException("Id为{$lesson}的课时不存在", null, 1002);
        }

        createService('Custom:Course.CourseService')->finishLearnLesson($lesson['courseId'], $lessonId);
        return array('success' => true);
    }

    public function cancelLearnLesson($lessonId)
    {
        $lesson = createService('Custom:Course.CourseService')->getLesson($lessonId);
        $course = createService('Custom:Course.CourseService')->getCourse($lesson['courseId']);
        if (empty($course)) {
            throw new AccessDeniedHttpException("Id为{$courseId}的课程不存在", null, 1001);
        }

        if (empty($lesson)) {
            throw new AccessDeniedHttpException("Id为{$lesson}的课时不存在", null, 1002);
        }

        createService('Custom:Course.CourseService')->cancelLearnLesson($lesson['courseId'], $lessonId);
        return array('success' => true);
    }

    public function startLearnLesson($lessonId)
    {
        
        $lesson = createService('Custom:Course.CourseService')->getLesson($lessonId);
        $course = createService('Custom:Course.CourseService')->getCourse($lesson['courseId']);
        if (empty($course)) {
            throw new AccessDeniedHttpException("Id为{$courseId}的课程不存在", null, 1001);
        }

        if (empty($lesson)) {
            throw new AccessDeniedHttpException("Id为{$lesson}的课时不存在", null, 1002);
        }

        createService('Custom:Course.CourseService')->startLearnLesson($lesson['courseId'], $lessonId);
        return array('success' => true);
    }
}