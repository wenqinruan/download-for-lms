<?php
namespace CmccApi\Service\Impl;

use CmccApi\Service\BaseService;
use Topxia\System;
use Topxia\Common\ArrayToolkit;
use Topxia\Common\FileToolkit;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * NoteServiceImpl errorcode prefix 12
 */
class NoteServiceImpl extends BaseService
{
    public function like($id)
    {
        createService('Course.NoteService')->like($id);
    }

    public function cancelLike($id)
    {
        createService('Course.NoteService')->cancelLike($id);
    }

    public function saveNote()
    {
        $courseId = $this->get('request')->request->get('courseId');
        $lessonId = $this->get('request')->request->get('lessonId');
        $content = $this->get('request')->request->get('content');
        $status = $this->get('request')->request->get('status', 1);
        $course = createService('Course.CourseService')->getCourse($courseId);
        
        if (empty($course)) {
            throw new AccessDeniedHttpException("Id为{$courseId}的课程不存在", null, 1001);
        }

        $lesson = createService('Course.CourseService')->getLesson($lessonId);
        if (empty($lesson)) {
            throw new AccessDeniedHttpException("Id为{$lesson}的课时不存在", null, 1002);
        }

        if (empty($content)) {
            throw new BadRequestHttpException("笔记内容不能为空", null, 1207);
        }

        $note = array(
            'courseId' => $courseId,
            'lessonId' => $lessonId,
            'content' => $content,
            'status' => $status == 'public' ? 1 : 0
        );
        
        $note = createService('Course.NoteService')->saveNote($note);

        $user = getCurrentUser();
        $note['owner']['name'] = $user['nickname'];
        $note['owner']['avatar'] = $user['smallAvatar'];
        $note['owner']['id'] = $user['id'];

        return $note;
    }

    public function searchNotes()
    {
        $sort = $this->get('request')->get('sort', 'latest');
        if (!in_array($sort, array('latest', 'likeNum'))) {
            throw new BadRequestHttpException('排序参数不对,参数值应该是latest,likeNum', null, 1302);
        }

        $conditions = array(
            'status' => $this->get('request')->get('status', 1) ? 1 : 0
        );

        if ($this->get('request')->get('lessonId')) {
            $lessonId = $this->get('request')->get('lessonId');
            $lesson = createService('Custom:Course.CourseService')->getLesson($lessonId);
            if (empty($lesson)) {
                throw new AccessDeniedHttpException("Id为{$lesson}的课时不存在", null, 1101);
                
            }

            $conditions['lessonId'] = $lessonId;
        }

        if ($this->get('request')->get('courseId')) {
            $conditions['courseId'] = $this->get('request')->get('courseId');
        }

        if ($this->get('request')->get('userId')) {
            $conditions['userId'] = $this->get('request')->get('userId');
        }

        $offset = $this->get('request')->get('start', 0);
        $limit = $this->get('request')->get('limit', 10);

        if ($sort == 'latest') {
            $sort = array(
                'createdTime' => 'DESC'
            );
        }

        if ($sort == 'likeNum') {
            $sort = array(
                'likeNum' => 'DESC'
            );
        }

        $notes = createService('Custom:Course.NoteService')->searchNotes($conditions, $sort, $offset, $limit);

        $total = createService('Custom:Course.NoteService')->searchNoteCount($conditions);

        $user = getCurrentUser();
        $noteLikes = createService('Custom:Course.NoteService')->findNoteLikesByNoteIdsAndUserId(ArrayToolkit::column($notes, 'id'), $user['id']);

        //$lessons = createService('Custom:COurse.CourseService')->findLessonsByIds(ArrayToolkit::column($notes, 'lessonId'));
        $users = createService('Custom:User.UserService')->findUsersByIds(ArrayToolkit::column($notes, 'userId'));
        foreach ($notes as &$note) {
            //等待批量获取课时的接口
            $note['lessonTitle'] = '测试课时';
            $user = $users[$note['userId']];
            $note['owner']['name'] = $user['nickname'];
            $note['owner']['avatar'] = $user['smallAvatar'];
            $note['owner']['id'] = $user['id'];

            if (!empty($noteLikes[$note['id']])) {
                $note['like'] = true;
            } else {
                $note['like'] = false;
            }
        }

        $response = array(
            'data' => $notes,
            'total' => $total
        );
        return $response;
    }

    public function upload()
    {
        $files = $this->get('request')->files->all();
        $data = array();
        foreach ($files as $key => $file) {
            if (!FileToolkit::isImageFile($file)) {
                throw new BadRequestHttpException("您上传的不是图片文件，请重新上传。", null, 1303);
            }
            $record = createService('Content.FileService')->uploadFile('course', $file);
            $url = $this->get('request')->getSchemeAndHttpHost() .'/files/'.substr($record['uri'], 9).'?'.System::VERSION;
            $data[] = array(
                'url' => $url
            );
        }
        $response = array(
            'data' => $data,
            'total' => count($data)
        );
        return $response;
    }
}
