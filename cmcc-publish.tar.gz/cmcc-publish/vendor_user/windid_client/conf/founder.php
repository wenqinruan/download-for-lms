<?php
  return array(
	'admin' => '9e1859803cabe274a28b5e39a171bf30',
);
?>