define(function(require, exports, module) {

	var BasePlugin = require('../base-plugin');

	var MaterialPane = require('./pane');

	var MaterialPlugin = BasePlugin.extend({
		code: 'material',
		name: '资料',
		iconClass: 'es-icon es-icon-icattachfileblack24px',
		api: {
			init: '../../lessonplugin/material/init'
		},
		execute: function() {
			if (!this.pane) {
				this.pane = new MaterialPane({
					element: this.toolbar.createPane(this.code),
					code: this.code,
					toolbar: this.toolbar,
					plugin: this
				}).render();
			}
			this.pane.show();
		},
		onChangeLesson: function() {
			this.pane.show();
		},
		onChangeMeta: function(lesson) {	
			if(!lesson){
				return;
			}
			if(lesson.materialNum>0){
				$('.es-icon-icattachfileblack24px').addClass('text-success');
				$('.toolbar-nav .es-icon-icattachfileblack24px').html('<span class="badge">'+lesson.materialNum+'</span>');
			}else{
				$('.es-icon-icattachfileblack24px').removeClass('text-success');
				$('.badge').remove();
			}
		}
	});

	module.exports = MaterialPlugin;

});