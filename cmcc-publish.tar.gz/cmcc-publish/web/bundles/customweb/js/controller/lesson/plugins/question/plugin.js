define(function(require, exports, module) {

    var BasePlugin = require('../base-plugin');

    var QuestionPane = require('./pane');

    var QuestionPlugin = BasePlugin.extend({
        code: 'question',
        name: '问答',
        iconClass: 'es-icon es-icon-livehelp',
        api: {
            init: /preview=1/.test(window.location.href) ? '../../lessonplugin/question/init?preview=1' : '../../lessonplugin/question/init',
            list: /preview=1/.test(window.location.href) ? '../../lessonplugin/question/list?preview=1' : '../../lessonplugin/question/list',
            show: /preview=1/.test(window.location.href) ? '../../lessonplugin/question/show?preview=1' : '../../lessonplugin/question/show',
            create: /preview=1/.test(window.location.href) ? '../../lessonplugin/question/create?preview=1' : '../../lessonplugin/question/create',
            answer: /preview=1/.test(window.location.href) ? '../../lessonplugin/question/answer?preview=1' : '../../lessonplugin/question/answer'
        },
        execute: function() {
            if (!this.pane) {
                this.pane = new QuestionPane({
                    element: this.toolbar.createPane(this.code),
                    plugin: this
                }).render();
            }

            this.pane.show();
        },

        onChangeLesson: function() {
            this.pane.show();
        }

    });

    module.exports = QuestionPlugin;

});